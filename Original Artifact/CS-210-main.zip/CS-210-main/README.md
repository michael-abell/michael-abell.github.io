# CS-210
Repository for SNHU CS 210

Summarize the project and what problem it was solving.
  At the end of each day a text file is created listing only the name of a product when it sells. This program takes that text file and makes the data seachable, and diplays the data both numerically and symbolicly.

What did you do particularly well?
  In this project I felt very good about the modularity of the code. It is clean cut and easy to figure out what each function does and how it relates to the main().

Where could you enhance your code? How would these improvements make your code more efficient, secure, and so on?
  There were a couple of loops that could have been their own functions as they were duplicated in three of the functions. Redundant code helps no one and that could clean it up.

Which pieces of the code did you find most challenging to write, and how did you overcome this? What tools or resources are you adding to your support network?
  I was recommended to use maps, which seem to be like dictionaries from Python. I was more comfortable with vectors and looping through them. Stack Overflow is a great resource because many answers are phrased as guiding thoughts rather than cut and paste the code.

What skills from this project will be particularly transferable to other projects or course work?
  Using vectors and loops will be critical in data analysis. I can see being able to search within the data being one of the most valuable parts.

How did you make this program maintainable, readable, and adaptable?
  Not only are there clear and concise comments all throughout my code, the comments are clean and organized as well. Functions refer to the program at large and are named for optimal coherance. 
