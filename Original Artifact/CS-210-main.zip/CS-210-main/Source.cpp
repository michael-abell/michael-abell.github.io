// Michael Abell, 06162023, a program to read, write, query and display info from a text file for analysis

#include "ItemTracking.h"	// connect the header file
#include <iostream>			// input output stream
#include <fstream>			// for opening and closing, reading and writing files
#include <string>			// working with strings
#include <vector>			// used vectors to store item names and quantities
#include <iomanip>			// needed this library for setfill and setw for symbols

using namespace std;		// standard library

int main()
{
	ItemTracking bu;		// run the backup .dat function before any loops happen
	bu.BackUp();			//
		
	ItemTracking mm;		// Main menu function utilizes all other functions to keep main small
	mm.MainMenu();			//
	
	    
	return 0;
}