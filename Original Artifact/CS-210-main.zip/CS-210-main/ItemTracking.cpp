#include "ItemTracking.h"                                           // these were commented in source.cpp
#include <iostream>                                                 //
#include <fstream>                                                  //
#include <string>                                                   //
#include <vector>                                                   //
#include <iomanip>                                                  //

using namespace std;                                                //


ItemTracking::ItemTracking() {	                                    // class contructor
}

void ItemTracking::MainMenu() {	                                    // Output for user to make a selection, utilizes switches in a while loop
    
    cout << "       *** Main Menu ***" << endl;                                                                         // Main display of instructions for user
    cout << endl;                                                                                                       //
    cout << endl;                                                                                                       //    
    cout << "Option 1: Search a specific item and retreive the quantity sold today." << endl;                           //
    cout << "Option 2: Displays a list of each item and its' quanity sold today." << endl;                              //
    cout << "Option 3: Displays a list of each item and displays a graph of how may items were sold today." << endl;    //
    cout << "Option 4: Quit program" << endl;                                                                           //
    cout << endl;                                                                                                       //
    cout << "Please Enter 1 2 3 or 4" << endl;                                                                          //
    cin >> choice;                                                  // get user input, this was defined as a private variable in ItemTracking.h

    while (choice < 1 || choice > 4)                                // input validation
    {
        cout << "Please enter a valid choice" << endl;
        cout << "Enter 1, 2, 3, or 4: " << endl;
        cin >> choice;                                              // try input again if it fell out of parameters
    }

    switch (choice)                                                 // switch takes the user input for it's argument
    {
    case 1:
        OptionOne();                                                // call function OptionOne
        cin.ignore();                                               // pause the screen
        cout << endl << "Press any key to continmue" << endl;       // user controls when to move screen along
        cin.get();                                                  // ignores input and proceeds
        system("cls");                                              // clear the screen
        MainMenu();                                                 // rerun MainMenu Functions from the start
    case 2:
        OptionTwo();                                                // call function OptionTwo
        cin.ignore();		
        cin.get();
        system("cls");
        MainMenu();
    case 3:
        OptionThree();                                              // call function OptionThree
        cin.ignore();		
        cin.get();
        system("cls");
        MainMenu();
    case 4:
        system("cls");                                              // clear screen
        cout << "Goodbye" << endl;                                  // Goodbye message output
        exit(0);                                                    // exit program

    }
}
    

int ItemTracking::OptionOne() {	                                    // Function search for word and returns a numeric frequency for that word "Item Search" used template from Zybooks
    ifstream inFS;                                                  // Input file stream        
    string userWord;                                                // local variable for storing the user input
    int wordFreq = 0;                                               // local variable delcared and initialized at 0 for word count
    string currWord;                                                // local temp variable to crosscheck user input with vector

    inFS.open("CS210_Project_Three_Input_File.txt");                // open the Corner Grocer's sales for the day

    if (!inFS.is_open()) {                                          // failsafe to make sure the doc actually got opened
        cout << "Could not open file CS210_Project_Three_Input_File.txt." << endl;
       return 1;
    }
    
    cout << "Enter the item name to see its' quantity: ";           // user instructions
    cin >> userWord;                                                // set input to local variable

    while (!inFS.eof()) {                                           // while loop until end of file is reached
        inFS >> currWord;                                           // read the word into temp variable currword
        if (!inFS.fail()) {                                         // another fail check
            if (currWord == userWord) {                             // if the word is already there,
                ++wordFreq;                                         // add plus one to it's frequency
            }
        }
    }

    cout << userWord << " was purchased " << wordFreq << " times today." << endl;   // output the results of the query

    inFS.close();                                                   // close the file

}

void ItemTracking::OptionTwo() {	// Print Item name then number of how many times it occcured "Item Count" Put names into one vector and item counts into the other                          
    
        ifstream in("CS210_Project_Three_Input_File.txt");          // opens Corner Grocers sales for the day
        vector<string> item_names;                                  // declare local vector for item names
        vector<int> item_counts;                                    // delcare local vector for quantity
        string line;                                                // local varibale for reading in from the doc

        while (getline(in, line))                                   // while loop to get each line
        {
            if (line.empty()) continue;                             // reaching a blank adds to vector

            item_names.push_back(line);                             // add to end of vector names
            item_counts.push_back(1);                               // add to count for quantity

            for (int i = 0; i < item_names.size() - 1; i++)         // for loop that runs for the amount of items in names vector
            {
                if (line == item_names[i])
                {
                    item_counts[i]++;
                    item_names.pop_back();
                    item_counts.pop_back();

                    break;
                }
            }
        }

        for (int i = 0; i < item_names.size(); i++){                // display loop for all items and quantities
            cout << item_names[i] << " " << item_counts[i] << endl; //
        }
    
}

void ItemTracking::OptionThree() {	                                // Print item name and a symbol for how many times it occured "Item Count Visualized"

        ifstream in("CS210_Project_Three_Input_File.txt");          // read from Corner Grocer Sales

        vector<string> item_names;                                  // local variable
        vector<int> item_counts;                                    // local variable        
        string line;                                                // local varibale

        while (getline(in, line))                                   // same while loop from OptionTwo()
        {
            if (line.empty()) continue;

            item_names.push_back(line);
            item_counts.push_back(1);

            for (int i = 0; i < item_names.size() - 1; i++)
            {
                if (line == item_names[i])
                {
                    item_counts[i]++;
                    item_names.pop_back();
                    item_counts.pop_back();

                    break;
                }
            }
        }

        for (int i = 0; i < item_names.size(); i++)                 // output loop that displays set character with the amount of items sold
        {
            int width = item_counts[i];
            cout << item_names[i] << " " << setw(static_cast<std::streamsize>(width) + 1) << setfill('*') << " " << endl; // compiler reccomended static_cast
        }
}

int ItemTracking::BackUp() {	                                    // Creates then closes an output file "frequency.dat" giving the results of Option 2

    ofstream outFS;                                                 // variable to start opening a file
    
    outFS.open("frequency.dat");                                    // open a new file

    if (!outFS.is_open()) {                                         // failsafe in case file doesn't open
        cout << "Could not open file frequency.dat." << endl;       //
        return 1;                                                   //
    }

    ifstream in("CS210_Project_Three_Input_File.txt");              // same code from OptionTwo to read from input file

    vector<string> item_names;
    vector<int> item_counts;

    string line;
    while (getline(in, line))
    {
        if (line.empty()) continue;

        item_names.push_back(line);
        item_counts.push_back(1);

        for (int i = 0; i < item_names.size() - 1; i++)             // for loop to orgaznize data
        {
            if (line == item_names[i])
            {
                item_counts[i]++;
                item_names.pop_back();
                item_counts.pop_back();

                break;
            }
        }
    }

    for (int i = 0; i < item_names.size(); i++)
    {
        outFS << item_names[i] << " " << item_counts[i] << endl;    // write each item and it's quantity to the file
    }

    outFS.close();                                                  // close the file
}