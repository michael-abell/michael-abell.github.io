#ifndef MY_CLASS_H				// guards
#define MY_CLASS_H				//

class ItemTracking				// class
{
	public:
		ItemTracking();			// public functions
		void MainMenu();		//
		int OptionOne();		//
		void OptionTwo();		//
		void OptionThree();		//
		int BackUp();			//
		
	private:
		int choice = 0;			// private variable declared and defined for MainMenu()
};

#endif